export const environment = {
  production: true,
  apiKey: '1a788676b927fd9d836e736fd6e92e25',
};
